#!/bin/bash

# Script para ejecutar casos de prueba para ASTARTraslados.py

# Ejecutar casos de prueba

python3 ASTARTraslados.py ./ASTAR-tests/mapa01.csv 1
python3 ASTARTraslados.py ./ASTAR-tests/mapa01.csv 2
python3 ASTARTraslados.py ./ASTAR-tests/mapa01.csv 3
python3 ASTARTraslados.py ./ASTAR-tests/mapa01.csv 4
python3 ASTARTraslados.py ./ASTAR-tests/mapa02.csv 1
python3 ASTARTraslados.py ./ASTAR-tests/mapa02.csv 2
python3 ASTARTraslados.py ./ASTAR-tests/mapa02.csv 3
python3 ASTARTraslados.py ./ASTAR-tests/mapa02.csv 4
python3 ASTARTraslados.py ./ASTAR-tests/mapa03.csv 1
python3 ASTARTraslados.py ./ASTAR-tests/mapa03.csv 2
python3 ASTARTraslados.py ./ASTAR-tests/mapa03.csv 3
python3 ASTARTraslados.py ./ASTAR-tests/mapa03.csv 4
python3 ASTARTraslados.py ./ASTAR-tests/mapa04.csv 1
python3 ASTARTraslados.py ./ASTAR-tests/mapa04.csv 2
python3 ASTARTraslados.py ./ASTAR-tests/mapa04.csv 3
python3 ASTARTraslados.py ./ASTAR-tests/mapa04.csv 4