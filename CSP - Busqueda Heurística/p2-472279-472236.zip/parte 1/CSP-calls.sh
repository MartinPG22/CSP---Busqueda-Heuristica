#!/bin/bash

# Script para ejecutar casos de prueba para CSPParking.py

# Ejecutar casos de prueba
python3 CSPParking.py ./CSP-tests/parking01.txt
python3 CSPParking.py ./CSP-tests/parking02.txt
python3 CSPParking.py ./CSP-tests/parking03.txt
python3 CSPParking.py ./CSP-tests/parking04.txt
python3 CSPParking.py ./CSP-tests/parking05.txt
python3 CSPParking.py ./CSP-tests/parking06.txt
python3 CSPParking.py ./CSP-tests/parking07.txt
python3 CSPParking.py ./CSP-tests/parking08.txt